<!DOCTYPE html>
<html>

<head>
    <title>BIODATA DIRI</title>
</head>

<body>
    <h1 align="center">BIODATA DIRI</h1>
    <table width="745" border="1" cellspacing="0" cellpadding="5" align="center">
        <tr align="center" bgcolor="#66CC33">
            <td width="174">DATA DIRI</td>
            <td width="353">KETERANGAN</td>
            <td width="232">FOTO</td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>Husnul Hotimah</td>
            <td rowspan="10" align="center"><img src="gambar.jpg" width="210" height="313"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>Jln. Senggani no.9</td>
        </tr>
        <tr>
            <td>No. Hp</td>
            <td>085247003680</td>
        </tr>
    </table>
</body>

</html>