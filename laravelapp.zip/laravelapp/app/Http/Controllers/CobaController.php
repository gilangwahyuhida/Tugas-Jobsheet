<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CobaController extends Controller{
   
    public function profil(){
        return view('profil');
    }
}
