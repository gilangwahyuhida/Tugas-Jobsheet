<!DOCTYPE html>
<html>
    <head>
        <title>Profil Saya Gilang</title>
    </head>
    <body>
        <h1>Profil Saya</h1>
        <p>Perkenalkan Nama Saya Gilang Wahyu Hidayat, Saya seorang Mahasiswa
        Jurusan Teknologi Informasi Prodi D-4 Teknik Informatika
        Saya Kelas TI-2A. 
        Sekian Terimakasih
        </p>
    </body>
</html>