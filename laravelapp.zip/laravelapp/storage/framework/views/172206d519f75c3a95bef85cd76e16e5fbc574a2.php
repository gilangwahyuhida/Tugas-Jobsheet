<!DOCTYPE html>
<html>
    <head>
        <title>Biodata</title>
    </head>
    <body>
        <h1>Biodata</h1>
        <p>Nama : <?php echo e($nama); ?></p>
        <p>Materi Mengajar</p>
            <ul>
            <?php $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datamateri): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($datamateri); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
    </body>
</html><?php /**PATH C:\xampp\htdocs\laravelapp\resources\views/biodata.blade.php ENDPATH**/ ?>