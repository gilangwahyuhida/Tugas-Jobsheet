<!-- Isi Title -->
<?php $__env->startSection('title', 'Tambah Data'); ?>

<!-- Isi Bagian Judul Halaman -->
<?php $__env->startSection('judul_halaman', 'Tambah Data Mahasiswa'); ?>

<!-- Isi Bagian Konten -->
<?php $__env->startSection('konten'); ?>
<a href="/mahasiswa" class="btn btn-danger">Kembali</a>
<br>
<br>
<!-- menampilkan error validasi -->
<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<!-- form validasi -->
<form action="/mahasiswa/simpan" method="post">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="nama">Nama</label>
        <input class="form-control" type="text" name="nama" value="<?php echo e(old('nama')); ?>">
    </div>
    <div class="form-group">
        <label for="nim">NIM</label>
        <input type="number" class="form-control" name="nim" value="<?php echo e(old('nim')); ?>">
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
    </div>
    <div class="form-group">
        <label for="jurusan">Jurusan</label>
        <input type="text" class="form-control" name="jurusan" value="<?php echo e(old('jurusan')); ?>">
    </div>
    <button type="submit" name="tambah" class="btn btn-primary float-right">Tambah Data</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/tambah.blade.php ENDPATH**/ ?>