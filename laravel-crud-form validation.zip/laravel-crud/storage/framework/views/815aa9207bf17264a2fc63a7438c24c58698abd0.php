<!-- isi title -->
<?php $__env->startSection('title', 'Validasi Data'); ?>

<!-- isi bagian judul halaman -->
<?php $__env->startSection('judul_halaman', 'Validasi Data Mahasiswa'); ?>

<!-- isi bagian konten -->
<?php $__env->startSection('konten'); ?>
<h3 class="my-4">Data Yang di Input : </h3>

<table class="table table-bordered table-striped">
    <tr>
        <td style="width: 150px">Nama</td>
        <td><?php echo e($data->nama); ?></td>
    </tr>
    <tr>
        <td>NIM</td>
        <td><?php echo e($data->nim); ?></td>
    </tr>
    <tr>
        <td>Email</td>
        <td><?php echo e($data->email); ?></td>
    </tr>
    <tr>
        <td>Jurusan</td>
        <td><?php echo e($data->jurusan); ?></td>
    </tr>
</table>

<a href="/mahasiswa" class="btn btn-primary">Kembali</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/simpan.blade.php ENDPATH**/ ?>