

<!-- Isi Title -->
<?php $__env->startSection('title', 'Detail Mahasiswa'); ?>

<!-- Isi Bagian Judul Halaman -->
<?php $__env->startSection('judul_halaman', 'Detail Data Mahasiswa'); ?>

<!-- Isi Bagian Konten -->
<?php $__env->startSection('konten'); ?>
<a href="/mahasiswa" class="btn btn-danger">Kembali</a>
<br>
<br>

<?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5 class="card-title"><?php echo e($mhs -> nama); ?></h5>
<p class="card-text">
    <label for=""><b>NIM : </b></label>
    <?php echo e($mhs -> nim); ?>

</p>
<p class="card-text">
    <label for=""><b>E-Mail : </b></label>
    <?php echo e($mhs -> email); ?>

</p>
<p class="card-text">
    <label for=""><b>Jurusan : </b></label>
    <?php echo e($mhs -> jurusan); ?>

</p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-crud\resources\views/detail.blade.php ENDPATH**/ ?>